import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY

const status = document.querySelector('#status')

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  status.textContent = 'Mode demo: isi VITE_SUPABASE_URL dan VITE_SUPABASE_ANON_KEY untuk menghubungkan backend.'
} else {
  const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  status.textContent = 'Supabase siap. Tahap berikutnya: autentikasi dan daftar perangkat.'
  // Realtime/device commands will be added after the database is connected.
}

document.querySelectorAll('[data-command]').forEach(button => {
  button.addEventListener('click', () => {
    alert(`Permintaan "${button.dataset.command}" akan dikirim setelah perangkat terhubung.`)
  })
})
